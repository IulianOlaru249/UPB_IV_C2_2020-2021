/*
  !-----------------------------------------------------------------------
  ! Author: Ruud van der Pas, Sun Microsystems
  ! 
  ! Copyright: Sun Microsystems, All rights reserved, Un-authorized
  !            distribution not permitted
  !-----------------------------------------------------------------------
*/
#define MIN(A,B) ( (A) < (B) ? (A) : (B) )

int threshold_col;
int threshold_row;
int nthreads;
