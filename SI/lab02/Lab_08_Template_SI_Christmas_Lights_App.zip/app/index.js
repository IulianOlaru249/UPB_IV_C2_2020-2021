// TODO ex1.1: Get all the globes references by the ID defined in index.view

// TODO ex1.2: Get the buttons references

// TODO ex1.3: Define colors for each globe's light turned on and turned off

// TODO ex1.4: Keep evidence of which globe's light is on/off

// TODO ex2.1: Create a function to turn all globes' lights off

// TODO ex3.2: Create first button globes' lights show function

// TODO ex4.2: Create second button globes' lights show function

// TODO ex5.2: Create third button globes' lights show function

// TODO ex3.1: Add an event when the first button is clicked to begin
//             the first lights show. The lights should all turn on and
//             off at a given interval (e.g. 200 ms). If the button is
//             pressed again the lights show should stop.

// TODO ex4.1: Add an event when the second button is clicked to begin
//             the second lights show. Only one light should turn on and
//             off at a given interval (e.g. 200 ms), then next one to it.
//             If the button is pressed again the lights show should stop.
//             If there was a light show already in action, the button will
//             stop it and it needs to be pressed again in order to start
//             the desired light show.

// TODO ex5.1: Add an event when the third button is clicked to begin
//             the third lights show. Be creative and implement it as you
//             want.
//             If the button is pressed again the lights show should stop.
//             If there was a light show already in action, the button will
//             stop it and it needs to be pressed again in order to start
//             the desired light show.

// TODO ex2.2: Start with all globes' lights turned off
